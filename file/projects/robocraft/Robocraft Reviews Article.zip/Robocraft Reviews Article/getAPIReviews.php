<!DOCTYPE html>
<HTML>
<BODY>

<?php
	
	
// Create connection to the database

	//login credentials
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "robocraft_reviews";
	
	$conn = new mysqli($servername, $username, $password, $dbname);
	$sql = "";
	$result = "";
	
// Check database connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	echo "Connected successfully to localhost database";
	
	ini_set("allow_url_fopen", 1);
	ini_set('max_execution_time', 0);
	
// data gather filters
	$cursor = '*';
	$fl_language = 'all';
	$gameid = "301520";
	
// assistance variables
	$count = 0;
	$i = 0;
	
	
	$url = "";
	$json = "";
	$json_decode = "";
	$success = 1;
	
			
//review variables
	$review = "";
	$recommendationid = "";
	
	$author = "";
	$steamid = "";
	$num_games_owned = "";
	$num_reviews = "";
	$playtime_forever = "";
	$playtime_last_two_weeks = "";
	$playtime_at_review = "";
	$last_played = "";
	
	$language = "";
	$review_text = "";
	$timestamp_created = "";
	$timestamp_updated = "";
	$voted_up = false;
	$votes_up = "";
	$votes_funny  = "";
	$weighted_vote_score = "";
	$comment_count = "";
	$steam_purchase = false;
	$received_for_free = false;
	$written_during_early_access = false;
	$developer_response = "";
	$timestamp_dev_responded = "";
	
	while($success == 1){
		
		echo "<br><br><br>";
		
		echo $count."° JSON Request, Cursor: '".$cursor."'";
		
		$url = "https://store.steampowered.com/appreviews/".$gameid."?json=1&purchase_type=all&language=".$fl_language."&num_per_page=100&filter=updated&cursor=".rawurlencode($cursor);
		$json = file_get_contents($url);
		$json_decode = json_decode($json);
		
		if(empty($json_decode))
			$success = 0;
		else{
			$success = $json_decode->success;
			
			if(!$json_decode->success === 1){
				echo "JSON request was unsuccessful";
				$cursor = null;
			}
			else{				
				echo "<br>JSON request success";
				echo "JSON response: <pre>". $json . "</pre>";
				if(isset($json_decode->query_summary->total_reviews))
					if($json_decode->query_summary->total_reviews != NULL && $json_decode->query_summary->total_reviews>0)
						echo "<br>total_reviews: ".$json_decode->query_summary->total_reviews;
				
				$reviews = $json_decode->reviews;
				foreach($reviews as $review){
					echo "<br><br>Record: ".$i;
					if(!isset($review->author))
						echo "<br>ERROR! No author key";
					else{
						$author = $review->author;
						if(!isset($author->steamid))
							echo "<br>ERROR! No steamid key";
						else{
							$steamid = $author->steamid;
							$sql = "
								SELECT 1
								FROM author
								WHERE steamid = ".$steamid.";";
							$result = $conn->query($sql);
							if (!empty($result) && $result->num_rows > 0){
								echo "<br>Author '".$steamid."' exists in the table author";
							}else{
								
								if(isset($author->num_games_owned))			$num_games_owned = $author->num_games_owned;
								
								if(isset($author->num_reviews))				$num_reviews = $author->num_reviews;
								
								if(isset($author->playtime_forever))		$playtime_forever = $author->playtime_forever;
								
								if(isset($author->playtime_last_two_weeks))	$playtime_last_two_weeks = $author->playtime_last_two_weeks;
								
								if(isset($author->playtime_at_review))		$playtime_at_review = $author->playtime_at_review;
								
								if(isset($author->last_played))				$last_played = $author->last_played;
									
								$sql = "
									INSERT INTO author
									VALUES ('".$steamid."','".$num_games_owned."','".$num_reviews."','".$playtime_forever."','".$playtime_last_two_weeks."','".$playtime_at_review."','".$last_played."')
								";
								
								if ($conn->query($sql) === TRUE)
									echo "<br>New author '".$steamid."' created successfully";
								else
									echo "<br>ERROR! ".$conn->error;
							}
							
							if(!isset($review->recommendationid))
								echo "ERROR! No recommendationid key";
							else{
								$recommendationid = $review->recommendationid;
								$sql = "
									SELECT 1
									FROM review
									WHERE recommendationid = ".$recommendationid.";";
								$result = $conn->query($sql);
								
								if (!empty($result) && $result->num_rows > 0)
									echo "<br>Review '".$recommendationid."' exists in the table review";
								else{
									if(isset($review->language))					$language = $review->language;
									
									if(isset($review->review))						$review_text = $review->review;
									
									if(isset($review->timestamp_created))			$timestamp_created = $review->timestamp_created;
									
									if(isset($review->timestamp_updated))			$timestamp_updated = $review->timestamp_updated;
									
									if(isset($review->voted_up))					$voted_up = $review->voted_up;
									
									if(isset($review->votes_up))					$votes_up = $review->votes_up;
									
									if(isset($review->votes_funny))					$votes_funny = $review->votes_funny;
									
									if(isset($review->weighted_vote_score))			$weighted_vote_score = $review->weighted_vote_score;
									
									if(isset($review->comment_count))				$comment_count = $review->comment_count;
									
									if(isset($review->steam_purchase))				$steam_purchase = $review->steam_purchase;
										
									if(isset($review->received_for_free))			$received_for_free = $review->received_for_free;
									
									if(isset($review->written_during_early_access))	$written_during_early_access = $review->written_during_early_access;
									
									if(isset($review->developer_response))			$developer_response = $review->developer_response;
									
									if(isset($review->timestamp_dev_responded))		$timestamp_dev_responded = $review->timestamp_dev_responded;
									
									$review_text = str_replace("\"", "'", $review_text);
									$developer_response = str_replace("\"", "'", $developer_response);
									
									$sql = "
										INSERT INTO review
										VALUES (\"".$recommendationid."\",\"".$steamid."\",\"".$language."\",\"".$review_text."\",\"".$timestamp_created."\",\"".$timestamp_updated."\",\"".$voted_up."\",\"".$votes_up."\",\"".$votes_funny."\",\"".$weighted_vote_score."\",\"".$comment_count."\",\"".$steam_purchase."\",\"".$received_for_free."\",\"".$written_during_early_access."\",\"".$developer_response."\",\"".$timestamp_dev_responded."\")
									";
									
									if ($conn->query($sql) === TRUE)
										echo "<br>New review '".$recommendationid."' created successfully";
									else
										echo "<br>ERROR! ".$conn->error;
								}
							}
						}
					}
					$i = $i + 1;
				}
				
				if($cursor == $json_decode->cursor){
					echo "<br><br><br>ERROR! Same cursor";
					$success = 0;
				}else
					$cursor = $json_decode->cursor;
			}
			
			$count = $count + 1;
		}
		
		echo "<br>END Loop";
	}
	
	$conn->close();
?>

</BODY>
</HTML>