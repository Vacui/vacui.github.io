-- Steam genres, six years later: queries behind the article
-- MariaDB 10.7. Tables: apps, genres, publishers (2026 data); app_legacy, genre_legacy (2020 data).
-- Prices are stored in cents. Queries are numbered as in the working notes, so numbers aren't consecutive.
-- Some queries are referenced in more than one section; each appears once, in the first section that uses it.


-- ============================================================================
-- SETUP (run first)
-- ============================================================================

-- Q22. HICP table and real prices table
-- Builds the inflation table (hicp_ea20) and the real prices table (apps_prices_real). Run it first: Q23, Q28, Q29 and Q31 read from these tables.
CREATE TABLE IF NOT EXISTS hicp_ea20 (yr SMALLINT PRIMARY KEY, idx DECIMAL(6,2));
INSERT IGNORE INTO hicp_ea20 VALUES
  (2014, 77.51), (2015, 77.66), (2016, 77.84), (2017, 79.04), (2018, 80.42),
  (2019, 81.38), (2020, 81.59), (2021, 83.70), (2022, 90.73), (2023, 95.65),
  (2024, 97.92), (2025, 100.00);

DROP TABLE IF EXISTS apps_prices_real;
CREATE TABLE apps_prices_real AS
SELECT p.*, ROUND(p.price_nominal * 100 / h.idx) AS price_2025
FROM (
  -- 2020 releases: price at the time, from the 2020 scrape.
  -- Soundtracks typed as DLC in 2020 and as music today count as music.
  SELECT 'scrape_2020' AS source, l.appid,
    CASE WHEN l.type = 'dlc' AND a.type = 'music' THEN 'music' ELSE l.type END AS type,
    YEAR(l.date) AS release_year, 2020 AS price_year, l.initial AS price_nominal
  FROM app_legacy l
  LEFT JOIN apps a ON a.appid = l.appid
  WHERE YEAR(l.date) = 2020
    AND l.currency = 'EUR'
    AND l.initial > 0
  UNION ALL
  -- 2021–2025 releases: today's price, assumed unchanged since launch
  SELECT 'current', a.appid, a.type,
    YEAR(a.release_date), YEAR(a.release_date), a.price_initial
  FROM apps a
  WHERE a.fetch_status = 'ok'
    AND COALESCE(a.coming_soon, 0) = 0
    AND a.release_date >= '2021-01-01' AND a.release_date < '2026-01-01'
    AND COALESCE(a.is_free, 0) = 0
    AND a.currency = 'EUR'
    AND a.price_initial > 0
) p
JOIN hicp_ea20 h ON h.yr = p.price_year;

-- Remove TigerQiuQiu and Hede (their games and the DLCs of their games)
-- from today's prices; 2020 scrape rows stay, as in the article
DELETE r
FROM apps_prices_real r
JOIN apps a ON a.appid = r.appid
WHERE r.source = 'current'
  AND EXISTS (SELECT 1 FROM publishers p
              WHERE p.publisher_name IN ('TigerQiuQiu', 'Hede')
                AND p.appid IN (a.appid, a.fullgame_appid));

-- ============================================================================
-- INTRODUCTION AND METHOD
-- ============================================================================

-- Q35. Totals in the introduction
-- Introduction: about 113,000 games, or 169,000 with DLCs, released up to 2025 with at least one of the ten genres. Result (13 November 2026): 113,313 / 168,952.
SELECT
  COUNT(DISTINCT CASE WHEN a.type = 'game' THEN a.appid END) AS games,
  COUNT(DISTINCT a.appid) AS games_and_dlcs
FROM apps a
JOIN genres g ON g.appid = a.appid
WHERE a.type IN ('game', 'dlc')
  AND a.fetch_status = 'ok'
  AND COALESCE(a.coming_soon, 0) = 0
  AND a.release_date < '2026-01-01'
  AND g.genre IN ('Action','Adventure','Casual','Indie','Massively Multiplayer',
                  'Racing','RPG','Simulation','Sports','Strategy');

-- Q3. Scope totals
-- Introduction: the size of the 2020 data (games and DLCs released by 2020 with at least one of the ten genres).
SELECT
  COUNT(DISTINCT CASE WHEN l.type = 'game' THEN l.appid END) AS games,
  COUNT(DISTINCT l.appid) AS games_and_dlcs
FROM app_legacy l
JOIN genre_legacy g ON g.appid = l.appid
WHERE l.type IN ('game', 'dlc')
  AND l.date > '1900-01-01'
  AND l.date < '2021-01-01'
  AND g.genre IN ('Action','Adventure','Casual','Indie','Massively Multiplayer',
                  'Racing','RPG','Simulation','Sports','Strategy');
SELECT
  COUNT(DISTINCT CASE WHEN a.type = 'game' THEN a.appid END) AS games,
  COUNT(DISTINCT a.appid) AS games_and_dlcs
FROM apps a
JOIN genres g ON g.appid = a.appid
WHERE a.type IN ('game', 'dlc')
  AND a.fetch_status = 'ok'
  AND COALESCE(a.coming_soon, 0) = 0
  AND a.release_date > '1900-01-01'
  AND a.release_date < '2021-01-01'
  AND g.genre IN ('Action','Adventure','Casual','Indie','Massively Multiplayer',
                  'Racing','RPG','Simulation','Sports','Strategy');

-- Q26. Games per year, all genres, 2020 scrape and today
-- Introduction, Releases and the genre shares: games released per year (9,242 in 2020, 21,098 in 2025), the share released 2021-2025, and the denominator for genre shares.
SELECT yr,
  SUM(src = '2020') AS games_2020_scrape,
  SUM(src = 'now') AS games_now
FROM (
  SELECT YEAR(l.date) AS yr, '2020' AS src
  FROM app_legacy l
  WHERE l.type = 'game'
    AND l.date > '1900-01-01' AND l.date < '2021-01-01'
  UNION ALL
  SELECT YEAR(a.release_date), 'now'
  FROM apps a
  WHERE a.type = 'game'
    AND a.fetch_status = 'ok'
    AND COALESCE(a.coming_soon, 0) = 0
    AND a.release_date > '1900-01-01' AND a.release_date < '2026-01-01'
) t
WHERE yr >= 2003
GROUP BY yr
ORDER BY yr;

-- Q28. Average price per year, all games
-- Introduction and 'Prices didn’t keep up with inflation': average price of paid games per year (EUR 8.40 in 2020, EUR 8.44 in 2025; EUR 10.30 in 2025 euros).
SELECT release_year,
  COUNT(*) AS paid_games,
  ROUND(AVG(price_nominal) / 100, 2) AS avg_nominal,
  ROUND(AVG(price_2025) / 100, 2) AS avg_2025_eur
FROM apps_prices_real
WHERE type = 'game'
  AND price_nominal < 19000
GROUP BY release_year
ORDER BY release_year;

-- Q16. Refetch outcome for apps in the 2020 data
-- Method: games from the 2020 data removed from the store (866 of 48,984 released by 2020, the 2%).
SELECT a.fetch_status,
  COUNT(*) AS apps,
  SUM(a.type = 'game') AS games,
  SUM(a.type = 'dlc') AS dlcs
FROM app_legacy l
JOIN apps a ON a.appid = l.appid
GROUP BY a.fetch_status;

-- Q19. Paid in 2020, no price now
-- Method: games paid in 2020 that are still listed but have no price (2,096; with Q16, the 6%).
SELECT a.fetch_status, a.type,
  COUNT(*) AS apps,
  SUM(a.release_date < '2021-01-01') AS released_by_2020
FROM app_legacy l
JOIN apps a ON a.appid = l.appid
WHERE l.initial > 0
  AND a.type IN ('game', 'dlc')
  AND COALESCE(a.is_free, 0) = 0
  AND a.price_initial IS NULL
GROUP BY a.fetch_status, a.type;

-- Q30. Same 2020 games, price then and now
-- Method and 'Prices didn’t keep up with inflation': the same 2020 games, price at launch vs today (6,849 games, -3.0% on average, 50% unchanged).
SELECT genre, COUNT(*) AS games,
  ROUND(AVG(p2020) / 100, 2) AS avg_2020,
  ROUND(AVG(pnow) / 100, 2) AS avg_now,
  ROUND(100 * (AVG(pnow) / AVG(p2020) - 1), 1) AS change_pct,
  SUM(pnow < p2020) AS cheaper,
  SUM(pnow = p2020) AS same,
  SUM(pnow > p2020) AS pricier
FROM (
  SELECT 'All games' AS genre, l.initial AS p2020, a.price_initial AS pnow
  FROM app_legacy l
  JOIN apps a ON a.appid = l.appid
  WHERE l.type = 'game' AND YEAR(l.date) = 2020
    AND l.currency = 'EUR' AND l.initial > 0 AND l.initial < 19000
    AND a.fetch_status = 'ok' AND a.currency = 'EUR'
    AND a.price_initial > 0 AND a.price_initial < 19000
  UNION ALL
  SELECT g.genre, l.initial, a.price_initial
  FROM app_legacy l
  JOIN apps a ON a.appid = l.appid
  JOIN genre_legacy g ON g.appid = l.appid
  WHERE l.type = 'game' AND YEAR(l.date) = 2020
    AND l.currency = 'EUR' AND l.initial > 0 AND l.initial < 19000
    AND a.fetch_status = 'ok' AND a.currency = 'EUR'
    AND a.price_initial > 0 AND a.price_initial < 19000
    AND g.genre IN ('Action','Adventure','Casual','Indie','Massively Multiplayer',
                    'Racing','RPG','Simulation','Sports','Strategy')
) t
GROUP BY genre
ORDER BY genre;

-- Q4. 2020 price baseline from the 2020 scrape
-- Method and price predictions: 2020 average prices from the 2020 data, reproducing the 2020 article.
SELECT g.genre,
  COUNT(*) AS paid_games_2020,
  ROUND(AVG(l.initial) / 100, 2) AS avg_2020_legacy
FROM app_legacy l
JOIN genre_legacy g ON g.appid = l.appid
WHERE l.type = 'game'
  AND YEAR(l.date) = 2020
  AND l.currency = 'EUR'
  AND l.initial > 0
  AND l.initial < 19000
  AND g.genre IN ('Action','Adventure','Casual','Indie','Massively Multiplayer',
                  'Racing','RPG','Simulation','Sports','Strategy')
GROUP BY g.genre
ORDER BY g.genre;

-- ============================================================================
-- CHECKING THE 2020 ARTICLE: RELEASES
-- ============================================================================

-- Q1. Games released per genre per year
-- Releases: games per genre per year and growth from 2020 to 2023 (Racing and RPG almost +60%, MMO +16%).
SELECT g.genre,
  SUM(YEAR(a.release_date) = 2019) AS y2019,
  SUM(YEAR(a.release_date) = 2020) AS y2020,
  SUM(YEAR(a.release_date) = 2021) AS y2021,
  SUM(YEAR(a.release_date) = 2022) AS y2022,
  SUM(YEAR(a.release_date) = 2023) AS y2023,
  SUM(YEAR(a.release_date) = 2024) AS y2024,
  SUM(YEAR(a.release_date) = 2025) AS y2025,
  ROUND(100 * (SUM(YEAR(a.release_date) = 2023)
             / NULLIF(SUM(YEAR(a.release_date) = 2020), 0) - 1), 1) AS growth_20_23_pct
FROM apps a
JOIN genres g ON g.appid = a.appid
WHERE a.type = 'game'
  AND a.fetch_status = 'ok'
  AND COALESCE(a.coming_soon, 0) = 0
  AND a.release_date >= '2019-01-01'
GROUP BY g.genre
ORDER BY y2020 DESC;

-- Q25. Games per year per genre, 2020 scrape and today
-- Releases and the genre shares: games per year per genre, 2003-2025 (chart 1 and chart 6).
SELECT yr, genre,
  SUM(src = '2020') AS games_2020_scrape,
  SUM(src = 'now') AS games_now
FROM (
  SELECT YEAR(l.date) AS yr, g.genre, '2020' AS src
  FROM app_legacy l
  JOIN genre_legacy g ON g.appid = l.appid
  WHERE l.type = 'game'
    AND l.date > '1900-01-01' AND l.date < '2021-01-01'
  UNION ALL
  SELECT YEAR(a.release_date), g.genre, 'now'
  FROM apps a
  JOIN genres g ON g.appid = a.appid
  WHERE a.type = 'game'
    AND a.fetch_status = 'ok'
    AND COALESCE(a.coming_soon, 0) = 0
    AND a.release_date > '1900-01-01' AND a.release_date < '2026-01-01'
) t
WHERE yr >= 2003
  AND genre IN ('Action','Adventure','Casual','Indie','Massively Multiplayer',
                'Racing','RPG','Simulation','Sports','Strategy')
GROUP BY yr, genre
ORDER BY genre, yr;

-- Q2. Market shares and free games per release year
-- Releases and price predictions: share of games carrying Action, Adventure or Casual (more than 80%) and free shares per year.
SELECT YEAR(a.release_date) AS yr,
  COUNT(*) AS games,
  ROUND(100 * SUM(EXISTS(SELECT 1 FROM genres g WHERE g.appid = a.appid
        AND g.genre IN ('Action','Adventure','Casual'))) / COUNT(*), 1) AS aac_pct,
  ROUND(100 * SUM(EXISTS(SELECT 1 FROM genres g WHERE g.appid = a.appid
        AND g.genre = 'Indie')) / COUNT(*), 1) AS indie_pct,
  ROUND(100 * SUM(a.is_free = 1) / COUNT(*), 1) AS free_pct,
  ROUND(100 * SUM(a.is_free = 1 AND EXISTS(SELECT 1 FROM genres g WHERE g.appid = a.appid
        AND g.genre = 'Massively Multiplayer'))
      / NULLIF(SUM(EXISTS(SELECT 1 FROM genres g WHERE g.appid = a.appid
        AND g.genre = 'Massively Multiplayer')), 0), 1) AS mmo_free_pct
FROM apps a
WHERE a.type = 'game'
  AND a.fetch_status = 'ok'
  AND COALESCE(a.coming_soon, 0) = 0
  AND a.release_date >= '2019-01-01' AND a.release_date < '2026-01-01'
GROUP BY yr
ORDER BY yr;

-- ============================================================================
-- CHECKING THE 2020 ARTICLE: PRICES
-- ============================================================================

-- Q6. Publishers of games priced €150 or more
-- The EUR 190 cutoff: publishers of games listed at EUR 150 or more.
SELECT p.publisher_name, YEAR(a.release_date) AS yr,
  COUNT(DISTINCT a.appid) AS games,
  ROUND(AVG(a.price_final) / 100, 2) AS avg_price_final
FROM apps a
JOIN publishers p ON p.appid = a.appid
WHERE a.type = 'game'
  AND a.fetch_status = 'ok'
  AND a.currency = 'EUR'
  AND a.price_initial >= 15000
GROUP BY p.publisher_name, yr
ORDER BY games DESC
LIMIT 20;

-- Q7. Price brackets from €100 to €200
-- The EUR 190 cutoff: games per EUR 10 price bracket from EUR 100 to EUR 200, which sets the cutoff.
SELECT FLOOR(a.price_initial / 1000) * 10 AS bracket_from_eur,
  SUM(YEAR(a.release_date) = 2020) AS y2020,
  SUM(YEAR(a.release_date) = 2023) AS y2023,
  SUM(YEAR(a.release_date) = 2025) AS y2025,
  COUNT(*) AS all_years
FROM apps a
WHERE a.type = 'game'
  AND a.fetch_status = 'ok'
  AND COALESCE(a.coming_soon, 0) = 0
  AND a.release_date > '1900-01-01'
  AND a.is_free = 0
  AND a.currency = 'EUR'
  AND a.price_initial >= 10000
  AND a.price_initial < 20000
GROUP BY bracket_from_eur
ORDER BY bracket_from_eur;

-- Q5. Average prices with the €190 cutoff
-- The EUR 190 cutoff and price predictions: average prices per genre with the cutoff (Sports EUR 10.59 in 2023; EUR 25.74 without the cutoff).
SELECT g.genre,
  ROUND(AVG(CASE WHEN YEAR(a.release_date) = 2020 AND a.price_initial < 19000 THEN a.price_initial END) / 100, 2) AS avg_2020,
  ROUND(AVG(CASE WHEN YEAR(a.release_date) = 2023 AND a.price_initial < 19000 THEN a.price_initial END) / 100, 2) AS avg_2023,
  ROUND(AVG(CASE WHEN YEAR(a.release_date) = 2025 AND a.price_initial < 19000 THEN a.price_initial END) / 100, 2) AS avg_2025,
  ROUND(100 * (AVG(CASE WHEN YEAR(a.release_date) = 2023 AND a.price_initial < 19000 THEN a.price_initial END)
             / AVG(CASE WHEN YEAR(a.release_date) = 2020 AND a.price_initial < 19000 THEN a.price_initial END) - 1), 1) AS growth_20_23_pct,
  SUM(YEAR(a.release_date) = 2020 AND a.price_initial >= 19000) AS excluded_2020,
  SUM(YEAR(a.release_date) = 2023 AND a.price_initial >= 19000) AS excluded_2023,
  SUM(YEAR(a.release_date) = 2025 AND a.price_initial >= 19000) AS excluded_2025
FROM apps a
JOIN genres g ON g.appid = a.appid
WHERE a.type = 'game'
  AND a.fetch_status = 'ok'
  AND COALESCE(a.coming_soon, 0) = 0
  AND YEAR(a.release_date) IN (2020, 2023, 2025)
  AND a.is_free = 0 AND a.price_initial > 0
  AND a.currency = 'EUR'
  AND g.genre IN ('Action','Adventure','Casual','Indie','Massively Multiplayer',
                  'Racing','RPG','Simulation','Sports','Strategy')
GROUP BY g.genre
ORDER BY avg_2023 DESC;

-- Q12. Games with the most DLCs released in 2021
-- DLC outlier: games with the most DLCs released in 2021.
SELECT a.fullgame_appid, f.name, COUNT(*) AS dlcs_2021
FROM apps a
LEFT JOIN apps f ON f.appid = a.fullgame_appid
WHERE a.type = 'dlc'
  AND a.fetch_status = 'ok'
  AND YEAR(a.release_date) = 2021
GROUP BY a.fullgame_appid, f.name
ORDER BY dlcs_2021 DESC
LIMIT 15;

-- Q13. DLCs released in 2021 by parent publisher
-- DLC outlier: DLCs released in 2021 by the publisher of their game (1,996 DLCs across 20 games for one publisher).
SELECT p.publisher_name,
  COUNT(DISTINCT a.fullgame_appid) AS parent_games,
  COUNT(DISTINCT a.appid) AS dlcs_2021
FROM apps a
JOIN publishers p ON p.appid = a.fullgame_appid
WHERE a.type = 'dlc'
  AND a.fetch_status = 'ok'
  AND COALESCE(a.coming_soon, 0) = 0
  AND YEAR(a.release_date) = 2021
GROUP BY p.publisher_name
ORDER BY dlcs_2021 DESC
LIMIT 15;

-- Q11. DLCs per genre per year, excluding TigerQiuQiu
-- DLC outlier and DLCs: DLCs per genre per year without that publisher (2025 records: Action 2,758, Indie 3,692, RPG 2,691, Simulation 2,439).
SELECT YEAR(a.release_date) AS yr,
  SUM(g.genre = 'Action') AS Action,
  SUM(g.genre = 'Adventure') AS Adventure,
  SUM(g.genre = 'Casual') AS Casual,
  SUM(g.genre = 'Indie') AS Indie,
  SUM(g.genre = 'Massively Multiplayer') AS MMO,
  SUM(g.genre = 'Racing') AS Racing,
  SUM(g.genre = 'RPG') AS RPG,
  SUM(g.genre = 'Simulation') AS Simulation,
  SUM(g.genre = 'Sports') AS Sports,
  SUM(g.genre = 'Strategy') AS Strategy
FROM apps a
JOIN genres g ON g.appid = a.appid
WHERE a.type = 'dlc'
  AND a.fetch_status = 'ok'
  AND COALESCE(a.coming_soon, 0) = 0
  AND a.release_date >= '2013-01-01' AND a.release_date < '2026-01-01'
  AND NOT EXISTS (SELECT 1 FROM publishers p
                  WHERE p.appid = a.fullgame_appid
                    AND p.publisher_name = 'TigerQiuQiu')
GROUP BY yr
ORDER BY yr;

-- Q23. Average prices by type, genre and year, nominal and real
-- Price predictions, 'Prices didn’t keep up with inflation' and DLC prices: average prices per type, genre and year, list and after inflation (chart 3, chart 7).
SELECT r.type, g.genre, r.release_year,
  COUNT(*) AS paid_apps,
  ROUND(AVG(r.price_nominal) / 100, 2) AS avg_nominal,
  ROUND(AVG(r.price_2025) / 100, 2) AS avg_2025_eur
FROM apps_prices_real r
JOIN (SELECT appid, genre, 'scrape_2020' AS source FROM genre_legacy
      UNION ALL
      SELECT appid, genre, 'current' FROM genres) g
  ON g.appid = r.appid AND g.source = r.source
WHERE r.type IN ('game', 'dlc')
  AND r.price_nominal < 19000
  AND g.genre IN ('Action','Adventure','Casual','Indie','Massively Multiplayer',
                  'Racing','RPG','Simulation','Sports','Strategy')
GROUP BY r.type, g.genre, r.release_year
ORDER BY r.type, g.genre, r.release_year;

-- Q27. Free games per year per genre
-- Price predictions and free games: free games per year per genre (about 15% in 2020, 16.6% in 2023, 14.3% in 2025; 3,106 in 2024).
SELECT yr, genre,
  COUNT(*) AS games,
  SUM(is_free = 1) AS free_games,
  ROUND(100 * SUM(is_free = 1) / COUNT(*), 1) AS free_pct
FROM (
  SELECT YEAR(a.release_date) AS yr, a.is_free, 'All games' AS genre
  FROM apps a
  WHERE a.type = 'game'
    AND a.fetch_status = 'ok'
    AND COALESCE(a.coming_soon, 0) = 0
    AND a.release_date >= '2003-01-01' AND a.release_date < '2026-01-01'
  UNION ALL
  SELECT YEAR(a.release_date), a.is_free, g.genre
  FROM apps a
  JOIN genres g ON g.appid = a.appid
  WHERE a.type = 'game'
    AND a.fetch_status = 'ok'
    AND COALESCE(a.coming_soon, 0) = 0
    AND a.release_date >= '2003-01-01' AND a.release_date < '2026-01-01'
    AND g.genre IN ('Action','Adventure','Casual','Indie','Massively Multiplayer',
                    'Racing','RPG','Simulation','Sports','Strategy')
) t
GROUP BY yr, genre
ORDER BY genre, yr;

-- ============================================================================
-- CHECKING THE 2020 ARTICLE: DLCS
-- ============================================================================

-- Q10. MMO games vs DLCs per year
-- DLCs: MMO games and DLCs per year (chart 4).
SELECT YEAR(a.release_date) AS yr,
  SUM(a.type = 'game') AS mmo_games,
  SUM(a.type = 'dlc') AS mmo_dlcs
FROM apps a
JOIN genres g ON g.appid = a.appid AND g.genre = 'Massively Multiplayer'
WHERE a.type IN ('game', 'dlc')
  AND a.fetch_status = 'ok'
  AND COALESCE(a.coming_soon, 0) = 0
  AND a.release_date >= '2010-01-01' AND a.release_date < '2026-01-01'
GROUP BY yr
ORDER BY yr;

-- ============================================================================
-- WHAT CHANGED SINCE 2020
-- ============================================================================

-- Q29. Paid games per price range, genre and year
-- 'More games, same prices': paid games per price range, genre and year (chart 5).
SELECT yr, genre, paid_games,
  eur_0_299, eur_3_499, eur_5_999, eur_10_1499, eur_15_2999, eur_30_4999, eur_50_plus, eur_190_plus
FROM (
  SELECT r.release_year AS yr, g.genre,
    COUNT(*) AS paid_games,
    SUM(r.price_nominal < 300) AS eur_0_299,
    SUM(r.price_nominal >= 300 AND r.price_nominal < 500) AS eur_3_499,
    SUM(r.price_nominal >= 500 AND r.price_nominal < 1000) AS eur_5_999,
    SUM(r.price_nominal >= 1000 AND r.price_nominal < 1500) AS eur_10_1499,
    SUM(r.price_nominal >= 1500 AND r.price_nominal < 3000) AS eur_15_2999,
    SUM(r.price_nominal >= 3000 AND r.price_nominal < 5000) AS eur_30_4999,
    SUM(r.price_nominal >= 5000 AND r.price_nominal < 19000) AS eur_50_plus,
    SUM(r.price_nominal >= 19000) AS eur_190_plus
  FROM apps_prices_real r
  JOIN (SELECT appid, genre, 'scrape_2020' AS source FROM genre_legacy
        UNION ALL
        SELECT appid, genre, 'current' FROM genres) g
    ON g.appid = r.appid AND g.source = r.source
  WHERE r.type = 'game'
    AND g.genre IN ('Action','Adventure','Casual','Indie','Massively Multiplayer',
                    'Racing','RPG','Simulation','Sports','Strategy')
  GROUP BY r.release_year, g.genre
  UNION ALL
  SELECT release_year, 'All games',
    COUNT(*),
    SUM(price_nominal < 300),
    SUM(price_nominal >= 300 AND price_nominal < 500),
    SUM(price_nominal >= 500 AND price_nominal < 1000),
    SUM(price_nominal >= 1000 AND price_nominal < 1500),
    SUM(price_nominal >= 1500 AND price_nominal < 3000),
    SUM(price_nominal >= 3000 AND price_nominal < 5000),
    SUM(price_nominal >= 5000 AND price_nominal < 19000),
    SUM(price_nominal >= 19000)
  FROM apps_prices_real
  WHERE type = 'game'
  GROUP BY release_year
) t
ORDER BY genre, yr;

-- Q32. Free, paid and neither, 2020–2025
-- Free games: free, paid and neither per year, checking that the 2025 fall isn’t unmarked free games.
SELECT YEAR(a.release_date) AS yr,
  COUNT(*) AS games,
  SUM(a.is_free = 1) AS free,
  SUM(COALESCE(a.is_free, 0) = 0 AND a.price_initial > 0) AS paid,
  SUM(COALESCE(a.is_free, 0) = 0 AND COALESCE(a.price_initial, 0) = 0) AS neither,
  SUM(a.is_free IS NULL) AS is_free_null
FROM apps a
WHERE a.type = 'game'
  AND a.fetch_status = 'ok'
  AND COALESCE(a.coming_soon, 0) = 0
  AND a.release_date >= '2020-01-01' AND a.release_date < '2026-01-01'
GROUP BY yr
ORDER BY yr;

-- Q21. EUR price points, 2020 vs 2026
-- 'Prices didn’t keep up with inflation': EUR price points in 2020 and today (EUR 9.75, 19.50 and 24.50 now on 6.9% of paid apps).
SELECT '2020 (legacy)' AS source, COUNT(*) AS paid,
  ROUND(100 * SUM(initial IN (975, 1950, 2450)) / COUNT(*), 1) AS pct_new_points,
  ROUND(100 * SUM(initial IN (819, 1679)) / COUNT(*), 1) AS pct_old_points
FROM app_legacy
WHERE currency = 'EUR' AND initial > 0
UNION ALL
SELECT '2026 (apps)', COUNT(*),
  ROUND(100 * SUM(price_initial IN (975, 1950, 2450)) / COUNT(*), 1),
  ROUND(100 * SUM(price_initial IN (819, 1679)) / COUNT(*), 1)
FROM apps
WHERE currency = 'EUR' AND price_initial > 0 AND fetch_status = 'ok';

-- Q31. DLC averages and medians per genre and year
-- DLC prices: DLC averages and medians per genre and year (EUR 8.05 in 2020, EUR 9.54 in 2025; median +2.0% after inflation).
SELECT DISTINCT yr, genre, n, avg_nominal, avg_2025_eur,
  ROUND(MEDIAN(price_nominal) OVER (PARTITION BY yr, genre) / 100, 2) AS median_nominal,
  ROUND(MEDIAN(price_2025) OVER (PARTITION BY yr, genre) / 100, 2) AS median_2025_eur
FROM (
  SELECT r.release_year AS yr, g.genre, r.price_nominal, r.price_2025,
    COUNT(*) OVER (PARTITION BY r.release_year, g.genre) AS n,
    ROUND(AVG(r.price_nominal) OVER (PARTITION BY r.release_year, g.genre) / 100, 2) AS avg_nominal,
    ROUND(AVG(r.price_2025) OVER (PARTITION BY r.release_year, g.genre) / 100, 2) AS avg_2025_eur
  FROM apps_prices_real r
  JOIN (SELECT appid, genre, 'scrape_2020' AS source FROM genre_legacy
        UNION ALL
        SELECT appid, genre, 'current' FROM genres) g
    ON g.appid = r.appid AND g.source = r.source
  WHERE r.type = 'dlc'
    AND r.price_nominal < 19000
    AND g.genre IN ('Action','Adventure','Casual','Indie','Massively Multiplayer',
                    'Racing','RPG','Simulation','Sports','Strategy')
  UNION ALL
  SELECT release_year, 'All DLCs', price_nominal, price_2025,
    COUNT(*) OVER (PARTITION BY release_year),
    ROUND(AVG(price_nominal) OVER (PARTITION BY release_year) / 100, 2),
    ROUND(AVG(price_2025) OVER (PARTITION BY release_year) / 100, 2)
  FROM apps_prices_real
  WHERE type = 'dlc' AND price_nominal < 19000
) t
ORDER BY genre, yr;

-- ============================================================================
-- DATA AND NOTES
-- ============================================================================

-- Q24. What became of the games priced 0 in 2020
-- Notes, free games and survivorship: what became of the games priced 0 in 2020 (at least 552 shut down, 229 of them MMOs).
SELECT a.fetch_status,
  CASE
    WHEN a.is_free = 1 THEN 'free now'
    WHEN a.price_initial > 0 THEN 'paid now'
    WHEN a.is_free IS NULL THEN 'is_free NULL'
    ELSE 'not free, no price'
  END AS status_now,
  COUNT(*) AS games,
  SUM(EXISTS (SELECT 1 FROM genre_legacy g
              WHERE g.appid = l.appid AND g.genre LIKE 'Free%Play')) AS f2p_tag_2020,
  SUM(EXISTS (SELECT 1 FROM genre_legacy g
              WHERE g.appid = l.appid AND g.genre = 'Massively Multiplayer')) AS mmo,
  SUM(EXISTS (SELECT 1 FROM genre_legacy g
              WHERE g.appid = l.appid AND g.genre = 'Massively Multiplayer')
      AND EXISTS (SELECT 1 FROM genre_legacy g
                  WHERE g.appid = l.appid AND g.genre LIKE 'Free%Play')) AS mmo_f2p_2020
FROM app_legacy l
JOIN apps a ON a.appid = l.appid
WHERE l.type = 'game'
  AND l.date > '1900-01-01' AND l.date < '2021-01-01'
  AND l.initial = 0
GROUP BY a.fetch_status, status_now
ORDER BY games DESC;

-- ============================================================================
-- SUPPORTING CHECKS AND DATA COLLECTION (not quoted in the article)
-- ============================================================================

-- Q8. Median prices
-- Supporting check: median prices, confirming the averages.
SELECT DISTINCT g.genre,
  ROUND(MEDIAN(l.initial) OVER (PARTITION BY g.genre) / 100, 2) AS median_2020_legacy
FROM app_legacy l
JOIN genre_legacy g ON g.appid = l.appid
WHERE l.type = 'game'
  AND YEAR(l.date) = 2020
  AND l.currency = 'EUR'
  AND l.initial > 0
  AND g.genre IN ('Action','Adventure','Casual','Indie','Massively Multiplayer',
                  'Racing','RPG','Simulation','Sports','Strategy')
ORDER BY g.genre;
SELECT genre,
  ROUND(MAX(CASE WHEN yr = 2020 THEN median_price END) / 100, 2) AS median_2020,
  ROUND(MAX(CASE WHEN yr = 2023 THEN median_price END) / 100, 2) AS median_2023,
  ROUND(MAX(CASE WHEN yr = 2025 THEN median_price END) / 100, 2) AS median_2025,
  ROUND(100 * (MAX(CASE WHEN yr = 2023 THEN median_price END)
             / MAX(CASE WHEN yr = 2020 THEN median_price END) - 1), 1) AS growth_20_23_pct
FROM (
  SELECT DISTINCT g.genre, YEAR(a.release_date) AS yr,
    MEDIAN(a.price_initial) OVER (PARTITION BY g.genre, YEAR(a.release_date)) AS median_price
  FROM apps a
  JOIN genres g ON g.appid = a.appid
  WHERE a.type = 'game'
    AND a.fetch_status = 'ok'
    AND COALESCE(a.coming_soon, 0) = 0
    AND YEAR(a.release_date) IN (2020, 2023, 2025)
    AND a.is_free = 0 AND a.price_initial > 0
    AND a.currency = 'EUR'
    AND g.genre IN ('Action','Adventure','Casual','Indie','Massively Multiplayer',
                    'Racing','RPG','Simulation','Sports','Strategy')
) m
GROUP BY genre
ORDER BY median_2023 DESC;

-- Q9. Store-wide free share
-- Supporting check: free share across the whole store (not used: affected by survivorship).
SELECT 'All games' AS scope,
  COUNT(*) AS games_to_2020,
  ROUND(100 * SUM(l.initial = 0) / COUNT(*), 1) AS free_pct_to_2020,
  SUM(l.initial IS NULL) AS price_null
FROM app_legacy l
WHERE l.type = 'game'
  AND l.date > '1900-01-01' AND l.date < '2021-01-01'
UNION ALL
SELECT 'MMO', COUNT(*),
  ROUND(100 * SUM(l.initial = 0) / COUNT(*), 1),
  SUM(l.initial IS NULL)
FROM app_legacy l
JOIN genre_legacy g ON g.appid = l.appid AND g.genre = 'Massively Multiplayer'
WHERE l.type = 'game'
  AND l.date > '1900-01-01' AND l.date < '2021-01-01';
SELECT 'All games' AS scope,
  ROUND(100 * SUM(a.is_free = 1 AND a.release_date < '2021-01-01')
            / SUM(a.release_date < '2021-01-01'), 1) AS free_pct_to_2020,
  ROUND(100 * SUM(a.is_free = 1 AND a.release_date < '2024-01-01')
            / SUM(a.release_date < '2024-01-01'), 1) AS free_pct_to_2023,
  ROUND(100 * SUM(a.is_free = 1) / COUNT(*), 1) AS free_pct_now
FROM apps a
WHERE a.type = 'game' AND a.fetch_status = 'ok'
  AND COALESCE(a.coming_soon, 0) = 0 AND a.release_date > '1900-01-01'
UNION ALL
SELECT 'MMO',
  ROUND(100 * SUM(a.is_free = 1 AND a.release_date < '2021-01-01')
            / SUM(a.release_date < '2021-01-01'), 1),
  ROUND(100 * SUM(a.is_free = 1 AND a.release_date < '2024-01-01')
            / SUM(a.release_date < '2024-01-01'), 1),
  ROUND(100 * SUM(a.is_free = 1) / COUNT(*), 1)
FROM apps a
JOIN genres g ON g.appid = a.appid AND g.genre = 'Massively Multiplayer'
WHERE a.type = 'game' AND a.fetch_status = 'ok'
  AND COALESCE(a.coming_soon, 0) = 0 AND a.release_date > '1900-01-01';

-- Q14. New data vs 2020 data
-- Supporting check: what changed between the 2020 data and today (types, dates, prices, names).
SELECT
  COUNT(*) AS legacy_apps,
  SUM(a.appid IS NULL) AS missing_in_new,
  SUM(a.fetch_status = 'skipped') AS skipped,
  SUM(a.fetch_status = 'failed') AS fetch_failed,
  SUM(a.appid IS NOT NULL AND NOT (a.type <=> l.type)) AS type_changed,
  SUM(a.appid IS NOT NULL AND NOT (a.release_date <=> l.date)) AS date_changed,
  SUM(a.appid IS NOT NULL AND a.currency = 'EUR' AND l.currency = 'EUR'
      AND NOT (a.price_initial <=> l.initial)) AS eur_price_changed,
  SUM(a.appid IS NOT NULL AND NOT (LEFT(a.name, 50) <=> l.name)) AS name_changed
FROM app_legacy l
LEFT JOIN apps a ON a.appid = l.appid;

-- Q15. Apps needing a refetch
-- Data collection: apps that needed a refetch.
SELECT
  SUM(no_pub AND never_checked) AS no_pub_never_checked,
  SUM(no_pub AND NOT never_checked) AS no_pub_checked,
  SUM(NOT no_pub AND never_checked) AS pub_never_checked,
  SUM(no_valid_date) AS no_valid_date,
  SUM(no_pub OR never_checked OR no_valid_date) AS total_to_refetch
FROM (
  SELECT a.appid,
    NOT EXISTS (SELECT 1 FROM publishers p WHERE p.appid = a.appid) AS no_pub,
    a.last_checked_at IS NULL AS never_checked,
    (COALESCE(a.coming_soon, 0) = 1
       OR a.release_date IS NULL
       OR a.release_date = '0000-00-00') AS no_valid_date
  FROM apps a
  WHERE a.fetch_status = 'ok'
    AND a.type IN ('game', 'dlc')
) t;

-- Q17. Release-date changes by kind
-- Data collection: release-date changes since 2020, checking they are real.
SELECT
  CASE
    WHEN l.date IS NULL OR l.date = '0000-00-00' THEN 'legacy had no date'
    WHEN a.release_date IS NULL OR a.release_date = '0000-00-00' THEN 'new has no date'
    WHEN ABS(DATEDIFF(a.release_date, l.date)) = 1 THEN '±1 day'
    WHEN DAY(a.release_date) = MONTH(l.date)
     AND MONTH(a.release_date) = DAY(l.date) THEN 'day/month swapped'
    WHEN YEAR(a.release_date) = YEAR(l.date) THEN 'same year'
    ELSE 'different year'
  END AS change_kind,
  COUNT(*) AS apps,
  SUM(a.last_checked_at IS NOT NULL) AS refetched,
  SUM(YEAR(l.date) = 2020 OR YEAR(a.release_date) = 2020) AS touches_2020
FROM app_legacy l
JOIN apps a ON a.appid = l.appid
WHERE NOT (a.release_date <=> l.date)
GROUP BY change_kind
ORDER BY apps DESC;

-- Q18. Games from the 2020 scrape released after 2020
-- Data collection: games in the 2020 data released after 2020.
SELECT YEAR(a.release_date) AS yr,
  COUNT(*) AS games_from_2020_scrape
FROM apps a
JOIN app_legacy l ON l.appid = a.appid
WHERE a.type = 'game'
  AND a.fetch_status = 'ok'
  AND COALESCE(a.coming_soon, 0) = 0
  AND a.release_date >= '2021-01-01' AND a.release_date < '2026-01-01'
GROUP BY yr
ORDER BY yr;

-- Q20. Direction of EUR price changes (games)
-- Supporting check: direction of EUR price changes since 2020.
SELECT
  COUNT(*) AS changed,
  SUM(a.price_initial < l.initial) AS lower_now,
  SUM(a.price_initial > l.initial) AS higher_now,
  SUM(a.price_initial = 0 OR a.is_free = 1) AS now_free_or_zero,
  ROUND(AVG(a.price_initial / l.initial), 3) AS avg_ratio_new_to_old
FROM app_legacy l
JOIN apps a ON a.appid = l.appid
WHERE a.type = 'game'
  AND a.currency = 'EUR' AND l.currency = 'EUR'
  AND l.initial > 0
  AND NOT (a.price_initial <=> l.initial);

-- Q33. MMO free share by release year in the 2020 scrape
-- Supporting check: MMO free share by release year in the 2020 data.
SELECT YEAR(l.date) AS yr,
  COUNT(*) AS mmo_games_2020_scrape,
  ROUND(100 * SUM(EXISTS (SELECT 1 FROM genre_legacy f
                          WHERE f.appid = l.appid AND f.genre LIKE 'Free%Play')) / COUNT(*), 1) AS f2p_tag_pct,
  ROUND(100 * SUM(l.initial = 0) / COUNT(*), 1) AS priced_0_pct
FROM app_legacy l
JOIN genre_legacy g ON g.appid = l.appid AND g.genre = 'Massively Multiplayer'
WHERE l.type = 'game'
  AND l.date >= '2014-01-01' AND l.date < '2021-01-01'
GROUP BY yr
ORDER BY yr;

-- Q34. Genre combinations
-- Supporting check: genre combinations (not used in the article).
SELECT combo, n_genres,
  COUNT(*) AS games_2019_2025,
  SUM(yr = 2020) AS y2020,
  SUM(yr = 2023) AS y2023,
  SUM(yr = 2025) AS y2025
FROM (
  SELECT a.appid, YEAR(a.release_date) AS yr,
    COALESCE(GROUP_CONCAT(g.genre ORDER BY g.genre SEPARATOR ' + '), '(none of the 10)') AS combo,
    COUNT(g.genre) AS n_genres
  FROM apps a
  LEFT JOIN genres g ON g.appid = a.appid
    AND g.genre IN ('Action','Adventure','Casual','Indie','Massively Multiplayer',
                    'Racing','RPG','Simulation','Sports','Strategy')
  WHERE a.type = 'game'
    AND a.fetch_status = 'ok'
    AND COALESCE(a.coming_soon, 0) = 0
    AND a.release_date >= '2019-01-01' AND a.release_date < '2026-01-01'
  GROUP BY a.appid, yr
) t
GROUP BY combo, n_genres
ORDER BY games_2019_2025 DESC;
