# Steam genres, six years later: data and queries

This package contains the data behind the article ["Steam genres, six years later"](https://vacui.github.io/projects/steam2026.html), a follow-up to [What Steam will look like in 3 years](https://www.gamedeveloper.com/business/what-steam-will-look-like-in-3-years) (2020). It lets you check every figure in the article, or rerun the analysis from the raw data.

Author: Matteo Graizzaro. Contact: [vacui.github.io](https://vacui.github.io/#contacts).

## Contents

| Path | What it is |
|---|---|
| `README.md` | This file |
| `key-figures.csv` | Every figure quoted in the article, with the query and file it comes from |
| `queries.sql` | Every query behind the article, grouped by article section |
| `charts/` | The data of the seven charts, as used in Datawrapper |
| `tables/` | Figures quoted in the article but not shown in a chart: average prices, free games, price-range counts, inflation index |
| `raw/` | The raw data: the 2026 data and the 2020 data, one CSV file per table (see Raw files) |
| `schema.sql` | Table definitions, to load `raw/` back into MariaDB |

## Sources

- **2026 data:** Steam’s public store API (the `appdetails` endpoint), collected from August to October 2026, with prices from the EU store in euros. Apps that returned no data after five attempts, ten minutes apart, are marked `skipped`.
- **2020 data:** the data collected in 2020 for the previous article, from the same API.
- **Inflation:** Eurostat, harmonised index of consumer prices, annual average, euro area (20 countries), [table tec00027](https://ec.europa.eu/eurostat/databrowser/view/TEC00027/default/table?lang=en), rebased to 2025 = 100 (`tables/hicp-euro-area.csv`).

## Definitions

- **Game, DLC:** the app type Steam reports. Soundtracks count as music, not DLCs, even where Steam listed them as DLCs in 2020.
- **Release year:** the year of the release date Steam reports today. Games not yet released (`coming_soon`) are left out, and so is 2026, which is incomplete.
- **Genres:** the ten genres of the 2020 article: Action, Adventure, Casual, Indie, Massively Multiplayer (MMO in the article and charts), Racing, RPG, Simulation, Sports and Strategy. A game counts in every genre it carries, so genre shares add up to more than 100%. A DLC counts in the genres it carries itself, which aren’t always those of its game.
- **Price:** the list price before any discount, in euros. Prices are stored in cents in the raw data and the queries.
- **Paid, free:** a game is free if Steam marks it as free. Averages and price ranges cover paid games only.
- **2020 prices** come from the 2020 data, so they’re launch prices. **Prices of games released from 2021** are today’s prices, treated as launch prices: the same 2020 games cost on average only 3% less today than at launch, and half never changed price (query Q30).
- **After inflation:** prices converted to 2025 euros with the index above. Euro area prices rose 22.6% from 2020 to 2025.

## Exclusions

- **Listings at €190 or more** are left out of all price averages. Most are small games listed at €194.99 from 2021 on; a few older games were raised to €194.99 with a permanent 95% discount. The cutoff comes from query Q7: the €190–199.99 bracket holds 292 games, against at most 21 in any other €10 bracket from €100 up.
- **Two publishers** are left out of all price figures for 2021–2025, together with the DLCs of their games: the one behind most of the €194.99 listings, and the one that released 1,996 DLCs across 20 games in 2021. The second is also left out of the DLC counts. Their 2020 rows stay in, as they were ordinary in 2020. Both are named in `queries.sql` (Q11, Q22).
- **Apps removed from the store** are left out of the counts. Of the 48,984 games in the 2020 data released by 2020, 866 (1.8%) have been removed; another 2,096 that were paid in 2020 are still listed without a price (Q16, Q19).

## Caveats

- **Survivorship in free games:** free status is today’s, so free games that have shut down drop out of the free counts. At least 552 games that were free in the 2020 data have shut down, 229 of them MMOs (Q24). Free shares of older release years are therefore too low; the article only compares them from 2020 onward.
- **Price ranges use list prices,** not prices after inflation: Steam prices sit just below round numbers (€4.99, €9.99), where the range edges fall, so adjusting older prices would push them into the next range. Ranges compare 2020, 2023 and 2025 only.
- **2021 and 2022 prices** are included in `tables/average-prices-games.csv` but not quoted in the article: those games have had the longest time to see their price cut.
- **Small genres** (MMO, Racing, Sports) have a few hundred paid games a year, so their averages move more from year to year.

## Raw files

| File | Contents |
|---|---|
| `apps.csv` | 2026 data: one row per app of any type, with its type, free flag, list and current price (in cents), release date, parent game for DLCs (`fullgame_appid`) and fetch status |
| `genres.csv` | 2026 data: one row per app and genre, with every genre Steam reports, not only the ten |
| `publishers.csv` | 2026 data: one row per app and publisher |
| `app_legacy.csv` | 2020 data: one row per app, with its type, price (`initial`, in cents) and release date (`date`) |
| `genre_legacy.csv` | 2020 data: one row per app and genre. In 2020, Steam also listed "Free to Play" as a genre |

All files are UTF-8, comma-separated, with values in double quotes, column names in the first row and NULL written as `\N`. Columns not used by the queries are kept as collected.

## Rerunning the analysis

1. Create an empty database, run `schema.sql` in it, then load the files in `raw/`. Because of the foreign keys, load `apps` before `genres` and `publishers`, and `app_legacy` before `genre_legacy` (or run `SET FOREIGN_KEY_CHECKS = 0;` while loading).
   To load a file from the MariaDB client (repeat for each table, in the order above):

   ```sql
   LOAD DATA LOCAL INFILE 'raw/apps.csv' INTO TABLE apps
     CHARACTER SET utf8mb4
     FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' ESCAPED BY '\\'
     LINES TERMINATED BY '\n'
     IGNORE 1 LINES;
   ```

   If the client refuses `LOCAL INFILE`, start it with `--local-infile=1`. If MariaDB warns about the last column of every row, the file has Windows line endings: use `LINES TERMINATED BY '\r\n'` instead.
2. Run Q22 in `queries.sql` first: it builds the inflation table (`hicp_ea20`) and the real prices table (`apps_prices_real`) that later queries use.
3. Run any other query. Each one starts with a comment saying where its result is used in the article. `key-figures.csv` goes the other way, from a figure in the article to its query.

Query numbers follow the working notes, so they aren’t consecutive.

## Licence

Everything in this package except the raw Steam data is licensed under [Creative Commons Attribution 4.0 International (CC BY 4.0)](https://creativecommons.org/licenses/by/4.0/): you can share and adapt it for any purpose, as long as you credit Matteo Graizzaro and link to the article. The raw data in `raw/` comes from Valve’s Steam store and isn’t covered by this licence; it’s shared for analysis and review.
