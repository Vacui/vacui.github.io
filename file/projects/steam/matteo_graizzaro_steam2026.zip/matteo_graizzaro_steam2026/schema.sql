-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 13, 2026 at 11:59 AM
-- Server version: 10.7.3-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `steam_genres2`
--

-- --------------------------------------------------------

--
-- Table structure for table `apps`
--

CREATE TABLE `apps` (
  `appid` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` enum('game','dlc','demo','mod','video','advertising','music','series','episode','application','hardware','movie') DEFAULT NULL,
  `is_free` tinyint(1) DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `price_initial` int(10) UNSIGNED DEFAULT NULL,
  `price_final` int(10) UNSIGNED DEFAULT NULL,
  `legacy_currency` char(3) DEFAULT NULL,
  `legacy_price_initial` int(10) UNSIGNED DEFAULT NULL,
  `legacy_exchange_rate` decimal(9,6) DEFAULT NULL,
  `windows` tinyint(1) NOT NULL DEFAULT 0,
  `mac` tinyint(1) NOT NULL DEFAULT 0,
  `linux` tinyint(1) NOT NULL DEFAULT 0,
  `coming_soon` tinyint(1) DEFAULT NULL,
  `release_date` date DEFAULT NULL,
  `release_date_raw` varchar(64) DEFAULT NULL,
  `positive_reviews` int(10) UNSIGNED DEFAULT NULL,
  `negative_reviews` int(10) UNSIGNED DEFAULT NULL,
  `total_reviews` int(10) UNSIGNED DEFAULT NULL,
  `fullgame_appid` int(10) UNSIGNED DEFAULT NULL,
  `recommendations_total` int(10) UNSIGNED DEFAULT NULL,
  `required_age` smallint(5) UNSIGNED DEFAULT NULL,
  `content_descriptor_notes` text DEFAULT NULL,
  `fetch_status` enum('pending','ok','failed','skipped') NOT NULL DEFAULT 'pending',
  `fetch_attempts` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `last_error` varchar(255) DEFAULT NULL,
  `last_checked_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `app_legacy`
--

CREATE TABLE `app_legacy` (
  `appid` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(15) NOT NULL,
  `currency` varchar(3) DEFAULT NULL,
  `initial` int(8) DEFAULT 0,
  `exchange_rate` decimal(5,4) NOT NULL,
  `initial_exchanged` int(8) NOT NULL,
  `windows` tinyint(1) NOT NULL DEFAULT 0,
  `mac` tinyint(1) NOT NULL DEFAULT 0,
  `linux` tinyint(1) NOT NULL DEFAULT 0,
  `coming_soon` tinyint(1) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `genres`
--

CREATE TABLE `genres` (
  `appid` int(10) UNSIGNED NOT NULL,
  `genre` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `genre_legacy`
--

CREATE TABLE `genre_legacy` (
  `appid` int(10) NOT NULL,
  `genre` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `publishers`
--

CREATE TABLE `publishers` (
  `appid` int(10) UNSIGNED NOT NULL,
  `publisher_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `apps`
--
ALTER TABLE `apps`
  ADD PRIMARY KEY (`appid`),
  ADD KEY `idx_type_date` (`type`,`release_date`),
  ADD KEY `idx_fetch_status` (`fetch_status`),
  ADD KEY `idx_fullgame_appid` (`fullgame_appid`);

--
-- Indexes for table `app_legacy`
--
ALTER TABLE `app_legacy`
  ADD PRIMARY KEY (`appid`),
  ADD UNIQUE KEY `UNIQUE` (`appid`,`name`) USING BTREE;

--
-- Indexes for table `genres`
--
ALTER TABLE `genres`
  ADD PRIMARY KEY (`appid`,`genre`),
  ADD KEY `idx_genre` (`genre`);

--
-- Indexes for table `genre_legacy`
--
ALTER TABLE `genre_legacy`
  ADD PRIMARY KEY (`appid`,`genre`);

--
-- Indexes for table `publishers`
--
ALTER TABLE `publishers`
  ADD PRIMARY KEY (`appid`,`publisher_name`),
  ADD KEY `idx_publisher_name` (`publisher_name`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `genres`
--
ALTER TABLE `genres`
  ADD CONSTRAINT `fx_genres_apps` FOREIGN KEY (`appid`) REFERENCES `apps` (`appid`) ON DELETE CASCADE;

--
-- Constraints for table `genre_legacy`
--
ALTER TABLE `genre_legacy`
  ADD CONSTRAINT `fx_genre_app` FOREIGN KEY (`appid`) REFERENCES `app_legacy` (`appid`);

--
-- Constraints for table `publishers`
--
ALTER TABLE `publishers`
  ADD CONSTRAINT `fx_publishers_apps` FOREIGN KEY (`appid`) REFERENCES `apps` (`appid`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
